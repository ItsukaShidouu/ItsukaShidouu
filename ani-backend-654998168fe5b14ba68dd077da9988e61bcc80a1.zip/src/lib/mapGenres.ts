import { load } from "cheerio";
import { extractSlugFromUrl, toAbsoluteOtakudesuUrl } from "@/lib/otakudesu";
import type { genre as genreType } from "@/types/types";

const mapGenres = (html: string): genreType[] => {
  const result: genreType[] = [];
  const genres = html
    .split("</a>")
    .filter((item) => item.trim() !== "")
    .map((item) => `${item}</a>`);

  genres.forEach((genre) => {
    const $ = load(genre);
    const href = $("a").attr("href");

    result.push({
      name: $("a").text(),
      slug: extractSlugFromUrl(toAbsoluteOtakudesuUrl(href), "genres"),
      otakudesu_url: toAbsoluteOtakudesuUrl(href),
    });
  });

  return result;
};

export default mapGenres;
