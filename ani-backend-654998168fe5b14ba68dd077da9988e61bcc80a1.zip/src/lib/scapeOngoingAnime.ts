import { load } from "cheerio";
import { extractSlugFromUrl } from "@/lib/otakudesu";
import type { ongoingAnime } from "@/types/types";

const scrapeOngoingAnime = (html: string): ongoingAnime[] => {
  const result: ongoingAnime[] = [];
  const animes = html
    .split("</li>")
    .filter((item) => item.trim() !== "")
    .map((item) => `${item}</li>`);

  animes.forEach((anime) => {
    const $ = load(anime);
    const animeUrl = $(".detpost .thumb a").attr("href");

    result.push({
      title: $(".detpost .thumb .thumbz .jdlflm").text(),
      slug: extractSlugFromUrl(animeUrl, "anime"),
      poster: $(".detpost .thumb .thumbz img").attr("src"),
      current_episode: $(".detpost .epz").text().trim(),
      release_day: $(".detpost .epztipe").text().trim(),
      newest_release_date: $(".detpost .newnime").text(),
      otakudesu_url: animeUrl,
    });
  });

  return result;
};

export default scrapeOngoingAnime;
