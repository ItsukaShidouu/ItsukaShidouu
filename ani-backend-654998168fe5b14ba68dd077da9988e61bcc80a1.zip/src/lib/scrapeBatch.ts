import { load } from 'cheerio';
import type { batch as batchType } from '@/types/types';

const scrapeBatch = (html: string): batchType => {
  const $ = load(html);

  // Cari container batch di beberapa kemungkinan lokasi
  const $batchContainer = $('.download2 .batchlink').length
    ? $('.download2 .batchlink')
    : $('.batchlink');

  const batch = $batchContainer.find('h4').first().text().trim() || '';

  const download_urls: {
    resolution: string | undefined;
    file_size: string | undefined;
    urls: {
      provider: string | undefined;
      url: string | undefined;
    }[];
  }[] = [];

  // Ambil setiap <li> di dalam <ul> pada container batch yang ditemukan
  $batchContainer.find('ul li').each((_, li) => {
    const $li = $(li);

    const resolutionText = $li.find('strong').first().text().trim();
    const resolution = resolutionText !== '' ? resolutionText : undefined;

    const fileSizeText = $li.find('i').first().text().trim();
    const file_size = fileSizeText !== '' ? fileSizeText : undefined;

    const urls = $li
      .find('a')
      .toArray()
      .map((a) => {
        const $a = $(a);
        const provider = $a.text().trim() || undefined;
        const url = $a.attr('href') || undefined;
        return { provider, url };
      });

    // Hanya push jika ada minimal satu URL atau info resolusi/file size
    if (urls.length > 0 || resolution || file_size) {
      download_urls.push({
        resolution,
        file_size,
        urls,
      });
    }
  });

  return {
    batch,
    download_urls,
  };
};

export default scrapeBatch;
