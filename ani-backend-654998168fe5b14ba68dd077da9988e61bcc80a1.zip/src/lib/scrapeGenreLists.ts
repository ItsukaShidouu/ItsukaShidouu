import { load } from "cheerio";
import { extractSlugFromUrl, toAbsoluteOtakudesuUrl } from "@/lib/otakudesu";
import type { genre as genreType } from "@/types/types";
const scrapeGenreLists = (html: string): genreType[] => {
  const $ = load(html);
  const result: genreType[] = [];
  const genres = $("#venkonten .vezone ul.genres li a")
    .toString()
    .split("</a>")
    .filter((el) => el.trim() !== "")
    .map((el) => `${el}</a>`);

  genres.forEach((genre) => {
    const $ = load(genre);
    const href = $("a").attr("href");
    result.push({
      name: $("a").text(),
      slug: extractSlugFromUrl(toAbsoluteOtakudesuUrl(href), "genres"),
      otakudesu_url: toAbsoluteOtakudesuUrl(href),
    });
  });

  return result;
};

export default scrapeGenreLists;
