import { load } from "cheerio";
import { extractSlugFromUrl } from "@/lib/otakudesu";
import type { genre } from "@/types/types";
import mapGenres from "./mapGenres";
import pagination from "./pagination";

const scrapeAnimeByGenre = (html: string) => {
  const $ = load(html);
  const animeElements = $(".venser .page .col-anime-con")
    .toString()
    .split('<div class="col-md-4 col-anime-con genre_2 genre_3 genre_4 genre_9 ">')
    .filter((element) => element.trim() !== '')
    .map((element) => `<div class="col-md-4 col-anime-con genre_2 genre_3 genre_4 genre_9 ">${element}`);

  const result: {
    title: string | undefined,
    slug: string | undefined,
    poster: string | undefined,
    rating: string | undefined,
    episode_count: string | null,
    season: string | undefined,
    studio: string | undefined,
    genres: genre[],
    synopsis: string | undefined,
    otakudesu_url: string | undefined
  }[] = [];

  animeElements.forEach((animeEl) => {
    const $ = load(animeEl);
    const animeUrl = $(".col-anime .col-anime-trailer a").attr("href");
    const episodeCount = $(".col-anime .col-anime-eps").text().replace(/[A-z]/g, "").trim();
    const genres = mapGenres($(".col-anime .col-anime-genre a").toString());

    result.push({
      title: $(".col-anime .col-anime-title a").text(),
      slug: extractSlugFromUrl(animeUrl, "anime"),
      poster: $(".col-anime .col-anime-cover img").attr("src"),
      rating: $(".col-anime .col-anime-rating").text() ?? null,
      episode_count: episodeCount === '' ? null : episodeCount,
      season: $(".col-anime .col-anime-date").text(),
      studio: $(".col-anime .col-anime-studio").text(),
      genres,
      synopsis: $(".col-anime .col-synopsis p").text(),
      otakudesu_url: animeUrl,
    });
  });

  return {
    anime: result,
    pagination: pagination(html)
  };
};

export default scrapeAnimeByGenre;
