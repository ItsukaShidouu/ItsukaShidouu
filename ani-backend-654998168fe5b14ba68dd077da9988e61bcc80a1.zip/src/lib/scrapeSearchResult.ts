import { load } from "cheerio";
import { extractSlugFromUrl } from "@/lib/otakudesu";
import type { searchResultAnime } from "@/types/types";
import mapGenres from "./mapGenres";

const scrapeSearchResult = (html: string): searchResultAnime[] => {
  const $ = load(html);
  const animes = $(".chivsrc li")
    .toString()
    .split("</li>")
    .filter((item) => item.trim() !== "")
    .map((item) => `${item}</li>`);
  const searchResult: searchResultAnime[] = [];

  animes.forEach((anime) => {
    const $ = load(anime);
    const animeUrl = $("h2 a").attr("href");
    const genres = mapGenres(
      $(".set:nth-child(3)")
        ?.html()
        ?.toString()
        .replace("<b>Genres</b> : ", "") as string,
    );

    searchResult.push({
      title: $("h2 a").text(),
      slug: extractSlugFromUrl(animeUrl, "anime"),
      poster: $("img").attr("src"),
      genres,
      status: $(".set:nth-child(4)").text()?.replace("Status : ", ""),
      rating: $(".set:last-child").text()?.replace("Rating : ", ""),
      url: animeUrl,
    });
  });

  return searchResult;
};

export default scrapeSearchResult;
