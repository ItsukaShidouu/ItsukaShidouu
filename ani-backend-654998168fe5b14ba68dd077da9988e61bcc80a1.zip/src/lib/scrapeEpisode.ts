import { load, CheerioAPI } from "cheerio";
import { extractSlugFromUrl } from "@/lib/otakudesu";
import type { episode as episodeType } from "@/types/types";

const enrichDownloadProvider = (provider: string | undefined, url: string | undefined) => {
  const lowerProvider = provider?.trim().toLowerCase();

  if ((lowerProvider === "pdrain" || lowerProvider === "pixeldrain") && url) {
    const pixeldrainMatch = url.match(/^https:\/\/pixeldrain\.com\/u\/([^/?#]+)$/);
    if (pixeldrainMatch) {
      const directUrl = `https://pixeldrain.com/api/file/${pixeldrainMatch[1]}`;
      return {
        provider,
        url,
        api_url: directUrl,
        direct_url: directUrl,
      };
    }
  }

  return {
    provider,
    url,
  };
};

const scrapeEpisode = (html: string): episodeType | undefined => {
  const $ = load(html);
  const episode = getEpisodeTitle($);
  const stream_url = getStreamUrl($);
  const mirrors = getMirrorData($);
  const download_urls = createDownloadData($);
  const previous_episode = getPrevEpisode($);
  const next_episode = getNextEpisode($);
  const anime = getAnimeData($);
  if (!episode) return undefined;

  return {
    episode,
    anime,
    has_next_episode: !!next_episode,
    next_episode,
    has_previous_episode: !!previous_episode,
    previous_episode,
    stream_url,
    mirrors,
    download_urls,
  };
};

const getEpisodeTitle = ($: CheerioAPI) => {
  return $(".venutama .posttl").text();
};

const getStreamUrl = ($: CheerioAPI) => {
  return $("#pembed iframe").attr("src");
};

const getMirrorData = ($: CheerioAPI) => {
  return $(".mirrorstream ul")
    .toArray()
    .map((element) => {
      const resolutionText = $(element).clone().children("li").remove().end().text().replace(/\s+/g, " ").trim();
      const resolution = resolutionText.match(/mirror\s+(.+)$/i)?.[1]?.trim() ?? resolutionText;
      const providers = $(element)
        .find("a[data-content]")
        .toArray()
        .map((anchor) => ({
          provider: $(anchor).text().trim(),
          data_content: $(anchor).attr("data-content") ?? "",
          is_default: $(anchor).attr("data-default") === "true",
          sources: [],
        }))
        .filter((item) => item.provider && item.data_content);

      return {
        resolution,
        providers,
      };
    })
    .filter((item) => item.providers.length > 0);
};

const createDownloadData = ($: CheerioAPI) => {
  const mp4 = getMp4DownloadUrls($);
  const mkv = getMkvDownloadUrls($);
  return {
    mp4,
    mkv,
  };
};

const getMp4DownloadUrls = ($: CheerioAPI) => {
  const result = [];
  const mp4DownloadEls = $(".download ul:first li")
    .toString()
    .split("</li>")
    .filter((item) => item.trim() !== "")
    .map((item) => `${item}</li>`);

  for (const el of mp4DownloadEls) {
    const $ = load(el);
    const downloadUrls = $("a")
      .toString()
      .split("</a>")
      .filter((item) => item.trim() !== "")
      .map((item) => `${item}</a>`);
    const urls = [];

    for (const downloadUrl of downloadUrls) {
      const $ = load(downloadUrl);
      urls.push(enrichDownloadProvider($("a").text(), $("a").attr("href")));
    }
    result.push({
      resolution: $("strong").text()?.replace(/([A-z][A-z]\d )/, ""),
      urls,
    });
  }

  return result;
};

const getMkvDownloadUrls = ($: CheerioAPI) => {
  const result = [];
  const mp4DownloadEls = $(".download ul:last li")
    .toString()
    .split("</li>")
    .filter((item) => item.trim() !== "")
    .map((item) => `${item}</li>`);

  for (const el of mp4DownloadEls) {
    const $ = load(el);
    const downloadUrls = $("a")
      .toString()
      .split("</a>")
      .filter((item) => item.trim() !== "")
      .map((item) => `${item}</a>`);
    const urls = [];

    for (const url of downloadUrls) {
      const $ = load(url);
      urls.push(enrichDownloadProvider($("a").text(), $("a").attr("href")));
    }
    result.push({
      resolution: $("strong").text()?.replace(/([A-z][A-z][A-z] )/, ""),
      urls,
    });
  }

  return result;
};

const getPrevEpisode = ($: CheerioAPI) => {
  const prevEpisodeLink = $('.flir a[title="Episode Sebelumnya"]').attr("href");

  if (prevEpisodeLink?.includes("/episode/")) {
    return {
      slug: extractSlugFromUrl(prevEpisodeLink, "episode"),
      otakudesu_url: prevEpisodeLink,
    };
  } else {
    return null;
  }
};

const getNextEpisode = ($: CheerioAPI) => {
  const nextEpisodeLink = $('.flir a[title="Episode Selanjutnya"]').attr("href");

  if (nextEpisodeLink?.includes("/episode/")) {
    return {
      slug: extractSlugFromUrl(nextEpisodeLink, "episode"),
      otakudesu_url: nextEpisodeLink,
    };
  } else {
    return null;
  }
};

const getAnimeData = ($: CheerioAPI) => {
  const animeUrl = $('.flir a[href*="/anime/"]').first().attr("href");
  const completeUrl = $('.flir a[href*="/lengkap/"]').first().attr("href");
  const resolvedUrl = animeUrl ?? completeUrl;
  const completeSlug = completeUrl
    ?.replace(/^https:\/\/otakudesu\.[a-zA-Z0-9-]+\/lengkap\//, '')
    .replace(/\/$/, '');

  return {
    slug: animeUrl
      ? extractSlugFromUrl(animeUrl, "anime")
      : completeSlug,
    otakudesu_url: resolvedUrl,
  };
};

export default scrapeEpisode;
