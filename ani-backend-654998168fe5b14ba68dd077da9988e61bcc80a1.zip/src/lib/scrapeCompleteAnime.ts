import { load } from "cheerio";
import { extractSlugFromUrl } from "@/lib/otakudesu";
import { completeAnime } from "@/types/types";

const scrapeCompleteAnime = (html: string): completeAnime[] => {
  const result: completeAnime[] = [];
  const animes = html
    .split("</li>")
    .filter((item) => item.trim() !== "")
    .map((item) => `${item}</li>`);

  animes.forEach((anime) => {
    const $ = load(anime);
    const animeUrl = $(".detpost .thumb a").attr("href");

    result.push({
      title: $(".detpost .thumb .thumbz .jdlflm").text(),
      slug: extractSlugFromUrl(animeUrl, "anime"),
      poster: $(".detpost .thumb .thumbz img").attr("src"),
      episode_count: $(".detpost .epz").text().trim().replace(" Episode", ""),
      rating: $(".detpost .epztipe").text().trim(),
      last_release_date: $(".detpost .newnime").text(),
      otakudesu_url: animeUrl,
    });
  });

  return result;
};

export default scrapeCompleteAnime;
