import { load } from 'cheerio';
import type { episode_list } from '@/types/types';

const scrapeAnimeEpisodes = (html: string): episode_list[] | undefined => {
  const result: episode_list[] = [];
  const $ = load(html);
  const visitedSlugs = new Set<string>();

  $('.episodelist li').each((_, element) => {
    const anchor = $(element).find('a').first();
    const href = anchor.attr('href');
    const titleText = anchor.text().trim();

    if (!href || !href.includes('/episode/')) {
      return;
    }

    const slug = href
      .replace(/^https:\/\/otakudesu\.[a-zA-Z0-9-]+\/episode\//, '')
      .replace(/\/$/, '');

    if (!slug || visitedSlugs.has(slug)) {
      return;
    }

    visitedSlugs.add(slug);

    const episodeNumberMatch = titleText.match(/episode\s+(\d+)/i) ?? titleText.match(/\b(\d+)\b/);
    const episodeTypeMatch = titleText.match(/\b(ova|special|movie|batch|ona)\b/i);

    result.push({
      episode: titleText,
      episode_number: episodeNumberMatch ? parseInt(episodeNumberMatch[1], 10) : undefined,
      episode_type: episodeTypeMatch?.[1]?.toLowerCase(),
      slug,
      otakudesu_url: href,
    });
  });

  return result;
};

export default scrapeAnimeEpisodes;
