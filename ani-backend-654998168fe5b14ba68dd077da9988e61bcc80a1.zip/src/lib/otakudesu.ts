const BASE_URL = process.env.BASEURL?.replace(/\/+$/, "") ?? "";

const buildOtakudesuUrl = (path: string): string => {
  const normalizedPath = path.startsWith("/") ? path : `/${path}`;
  return `${BASE_URL}${normalizedPath}`;
};

const extractSlugFromUrl = (url: string | undefined, segment: "anime" | "episode" | "batch" | "genres") => {
  if (!url) {
    return undefined;
  }

  const matcher = new RegExp(`^https:\\/\\/otakudesu\\.[a-zA-Z0-9-]+\\/${segment}\\/(.+?)\\/?$`);
  return url.replace(matcher, "$1").replace(/\/$/, "");
};

const toAbsoluteOtakudesuUrl = (url: string | undefined) => {
  if (!url) {
    return undefined;
  }

  if (/^https?:\/\//.test(url)) {
    return url;
  }

  return buildOtakudesuUrl(url);
};

export { BASE_URL, buildOtakudesuUrl, extractSlugFromUrl, toAbsoluteOtakudesuUrl };
