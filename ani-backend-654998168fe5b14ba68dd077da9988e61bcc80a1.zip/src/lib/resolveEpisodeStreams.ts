import axios from "axios";
import { load } from "cheerio";

type EpisodeVideoSource = {
  label: string;
  url: string;
  source: string;
  type: "iframe" | "video" | "embed" | "api";
  mime_type?: string | undefined;
};

type EpisodeMirrorProvider = {
  provider: string;
  data_content: string;
  is_default: boolean;
  iframe_url?: string | undefined;
  sources: EpisodeVideoSource[];
};

type EpisodeMirrorGroup = {
  resolution: string;
  providers: EpisodeMirrorProvider[];
};

const REQUEST_HEADERS = {
  "User-Agent": "Mozilla/5.0",
};
const AJAX_URL = "https://otakudesu.blog/wp-admin/admin-ajax.php";
const NONCE_ACTION = "aa1208d27f29ca340c92c66d1926f13f";
const MIRROR_ACTION = "2a3505c93b0035d3f455df82bf976b84";

const normalizeUrl = (url: string | undefined, baseUrl?: string) => {
  if (!url) {
    return undefined;
  }

  const decodedUrl = url.replace(/&amp;/g, "&").trim();

  try {
    return new URL(decodedUrl, baseUrl).toString();
  } catch {
    return undefined;
  }
};

const buildModeJsonUrl = (url: string) => {
  try {
    const parsedUrl = new URL(url);
    parsedUrl.searchParams.set("mode", "json");
    parsedUrl.searchParams.set("_", Date.now().toString());
    return parsedUrl.toString();
  } catch {
    return undefined;
  }
};

const fetchHtml = async (url: string) => {
  const response = await axios.get<string>(url, {
    headers: REQUEST_HEADERS,
    timeout: 15000,
  });

  return response.data;
};

const extractPageSources = (html: string, pageUrl: string): EpisodeVideoSource[] => {
  const $ = load(html);
  const sources: EpisodeVideoSource[] = [];

  const pushSource = (source: EpisodeVideoSource | undefined) => {
    if (!source?.url) {
      return;
    }

    if (sources.some((item) => item.url === source.url && item.type === source.type)) {
      return;
    }

    sources.push(source);
  };

  $("iframe[src]").each((_, element) => {
    const url = normalizeUrl($(element).attr("src"), pageUrl);
    if (!url) {
      return;
    }

    pushSource({
      label: new URL(url).hostname,
      url,
      source: pageUrl,
      type: "iframe",
    });
  });

  $("video[src], source[src]").each((_, element) => {
    const url = normalizeUrl($(element).attr("src"), pageUrl);
    if (!url) {
      return;
    }

    pushSource({
      label: $(element).attr("label")?.trim() || $(element).attr("res")?.trim() || new URL(url).hostname,
      url,
      source: pageUrl,
      type: "video",
      mime_type: $(element).attr("type")?.trim(),
    });
  });

  $('meta[property="og:video"], meta[property="og:video:url"], meta[property="twitter:player"]').each((_, element) => {
    const url = normalizeUrl($(element).attr("content"), pageUrl);
    if (!url) {
      return;
    }

    pushSource({
      label: new URL(url).hostname,
      url,
      source: pageUrl,
      type: "embed",
      mime_type: $('meta[property="og:video:type"]').attr("content")?.trim(),
    });
  });

  return sources;
};

const extractModeJsonSource = async (pageUrl: string): Promise<EpisodeVideoSource | undefined> => {
  const modeJsonUrl = buildModeJsonUrl(pageUrl);
  if (!modeJsonUrl) {
    return undefined;
  }

  try {
    const response = await axios.get<{ video?: string }>(modeJsonUrl, {
      headers: {
        ...REQUEST_HEADERS,
        Accept: "application/json",
      },
      timeout: 15000,
    });

    const videoUrl = normalizeUrl(response.data?.video, pageUrl);
    if (!videoUrl) {
      return undefined;
    }

    return {
      label: new URL(videoUrl).hostname,
      url: videoUrl,
      source: pageUrl,
      type: "api",
    };
  } catch {
    return undefined;
  }
};

const resolveEpisodeStreamUrls = async (streamUrl: string | undefined): Promise<EpisodeVideoSource[]> => {
  if (!streamUrl) {
    return [];
  }

  const sources: EpisodeVideoSource[] = [
    {
      label: "primary",
      url: streamUrl,
      source: streamUrl,
      type: "iframe",
    },
  ];
  const visited = new Set<string>();
  const queue: { url: string; depth: number }[] = [{ url: streamUrl, depth: 0 }];

  while (queue.length > 0) {
    const current = queue.shift();
    if (!current || visited.has(current.url) || current.depth > 1) {
      continue;
    }

    visited.add(current.url);

    try {
      const html = await fetchHtml(current.url);
      const pageSources = extractPageSources(html, current.url);

      for (const pageSource of pageSources) {
        if (!sources.some((item) => item.url === pageSource.url && item.type === pageSource.type)) {
          sources.push(pageSource);
        }

        if (pageSource.type === "iframe" && current.depth < 1 && !visited.has(pageSource.url)) {
          queue.push({ url: pageSource.url, depth: current.depth + 1 });
        }
      }

      const modeJsonSource = await extractModeJsonSource(current.url);
      if (modeJsonSource && !sources.some((item) => item.url === modeJsonSource.url && item.type === modeJsonSource.type)) {
        sources.push(modeJsonSource);
      }
    } catch {
      continue;
    }
  }

  return sources;
};

let noncePromise: Promise<string | undefined> | undefined;

const getMirrorNonce = async () => {
  if (!noncePromise) {
    noncePromise = axios.post<{ data?: string }>(
      AJAX_URL,
      new URLSearchParams({ action: NONCE_ACTION }).toString(),
      {
        headers: {
          ...REQUEST_HEADERS,
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        },
        timeout: 15000,
      },
    )
      .then((response) => response.data?.data)
      .catch(() => undefined);
  }

  return noncePromise;
};

const decodeMirrorPayload = (payload: string) => {
  try {
    return JSON.parse(Buffer.from(payload, "base64").toString("utf8")) as { id: number; i: number; q: string };
  } catch {
    return undefined;
  }
};

const resolveMirrorIframeUrl = async (payload: string) => {
  const decodedPayload = decodeMirrorPayload(payload);
  const nonce = await getMirrorNonce();

  if (!decodedPayload || !nonce) {
    return undefined;
  }

  try {
    const response = await axios.post<{ data?: string }>(
      AJAX_URL,
      new URLSearchParams({
        id: String(decodedPayload.id),
        i: String(decodedPayload.i),
        q: decodedPayload.q,
        nonce,
        action: MIRROR_ACTION,
      }).toString(),
      {
        headers: {
          ...REQUEST_HEADERS,
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        },
        timeout: 15000,
      },
    );

    const html = response.data?.data ? Buffer.from(response.data.data, "base64").toString("utf8") : "";
    const $ = load(html);
    return normalizeUrl($("iframe").attr("src"));
  } catch {
    return undefined;
  }
};

const resolveEpisodeMirrors = async (mirrors: EpisodeMirrorGroup[]): Promise<EpisodeMirrorGroup[]> => {
  return Promise.all(
    mirrors.map(async (group) => ({
      resolution: group.resolution,
      providers: await Promise.all(
        group.providers.map(async (provider) => {
          const iframeUrl = await resolveMirrorIframeUrl(provider.data_content);
          const sources = iframeUrl ? await resolveEpisodeStreamUrls(iframeUrl) : [];

          return {
            ...provider,
            iframe_url: iframeUrl,
            sources,
          };
        }),
      ),
    })),
  );
};

export type { EpisodeMirrorGroup, EpisodeMirrorProvider, EpisodeVideoSource };
export { resolveEpisodeMirrors };
export default resolveEpisodeStreamUrls;
