import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json(
    [
      {
        message: "Otakudesu unofficial API, made by yusupkakuu with 🤍",
        GitHub: "https://github.com/neofetchnpc",
        Support: "https://saweria.co/YUSUP909",
      },
    ],
    { status: 200 },
  );
}
