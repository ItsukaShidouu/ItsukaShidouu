import { NextResponse } from "next/server";
import ongoingAnime from "@/utils/ongoingAnime";

export const dynamic = "force-dynamic";

export async function GET(_: Request, props: { params: Promise<{ id: number }> }) {
  const params = await props.params;
  const data = await ongoingAnime(params.id);
  return NextResponse.json({ data }, { status: 200 });
}
