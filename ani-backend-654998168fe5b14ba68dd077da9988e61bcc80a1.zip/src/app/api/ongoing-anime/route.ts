import { NextResponse } from "next/server";
import ongoingAnime from "@/utils/ongoingAnime";

export const dynamic = "force-dynamic";

export async function GET() {
  const data = await ongoingAnime();
  return NextResponse.json({ data }, { status: 200 });
}
