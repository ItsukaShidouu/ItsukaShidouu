import { NextResponse } from "next/server";
import home from "@/utils/home";

export const dynamic = "force-dynamic";

export async function GET() {
  const data = await home();
  return NextResponse.json({ data }, { status: 200 });
}
