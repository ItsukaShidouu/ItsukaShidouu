import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json({ data: "You have to add [:page]" }, { status: 404 });
}
