import { NextResponse } from "next/server";
import completeAnime from "@/utils/completeAnime";

export const dynamic = "force-dynamic";

export async function GET(_: Request, props: { params: Promise<{ page: number }> }) {
  const params = await props.params;
  const data = await completeAnime(params.page);
  return NextResponse.json({ data }, { status: 200 });
}
