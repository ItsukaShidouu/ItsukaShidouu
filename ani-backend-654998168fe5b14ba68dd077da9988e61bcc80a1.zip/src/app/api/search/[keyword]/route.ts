import { NextResponse } from "next/server";
import search from "@/utils/search";

export const dynamic = "force-dynamic";

export async function GET(_: Request, props: { params: Promise<{ keyword: string }> }) {
  const params = await props.params;
  const data = await search(params.keyword);
  return NextResponse.json({ data }, { status: 200 });
}
