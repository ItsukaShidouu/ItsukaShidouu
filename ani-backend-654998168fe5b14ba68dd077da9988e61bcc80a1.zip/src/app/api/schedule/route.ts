import { NextResponse } from "next/server";
import schedule from "@/utils/schedulte";

export const dynamic = "force-dynamic";

export async function GET() {
  const data = await schedule();
  return NextResponse.json({ data }, { status: 200 });
}
