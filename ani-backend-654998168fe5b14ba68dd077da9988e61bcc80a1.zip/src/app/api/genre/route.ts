import { NextResponse } from "next/server";
import genreLists from "@/utils/genreLists";

export const dynamic = "force-dynamic";

export async function GET() {
  const data = await genreLists();
  return NextResponse.json({ data }, { status: 200 });
}
