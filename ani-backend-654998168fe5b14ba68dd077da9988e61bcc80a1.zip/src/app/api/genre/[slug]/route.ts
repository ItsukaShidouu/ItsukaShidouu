import { NextResponse } from "next/server";
import animeByGenre from "@/utils/animeByGenre";

export const dynamic = "force-dynamic";

export async function GET(request: Request, props: { params: Promise<{ slug: string }> }) {
  const params = await props.params;
  const { searchParams } = new URL(request.url);
  const reqPage = searchParams.get("page");
  const pageNumber = reqPage ? parseInt(reqPage, 10) : 1;
  const data = await animeByGenre(params.slug, pageNumber);
  return NextResponse.json({ data }, { status: 200 });
}
