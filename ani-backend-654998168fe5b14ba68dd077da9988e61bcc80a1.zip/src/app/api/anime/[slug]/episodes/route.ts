import { NextResponse } from "next/server";
import movie from "@/utils/movie";

export const dynamic = "force-dynamic";

export async function GET(_: Request, props: { params: Promise<{ slug: string }> }) {
  const { slug } = await props.params;
  const data = await movie(slug);
  return NextResponse.json({ data }, { status: 200 });
}
