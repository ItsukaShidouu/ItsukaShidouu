import { NextResponse } from "next/server";
import episode from "@/utils/episode";

export const dynamic = "force-dynamic";

export async function GET(_: Request, props: { params: Promise<{ slug: string; episode: string }> }) {
  const params = await props.params;
  const isNumericEpisode = /^\d+$/.test(params.episode);
  const data = await episode({
    animeSlug: params.slug,
    episodeNumber: isNumericEpisode ? parseInt(params.episode, 10) : undefined,
    episodeQuery: isNumericEpisode ? undefined : params.episode,
  });
  return NextResponse.json({ data }, { status: 200 });
}
