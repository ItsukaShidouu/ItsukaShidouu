import { NextResponse } from "next/server";
import anime from "@/utils/anime";

export const dynamic = "force-dynamic";

export async function GET(_: Request, props: { params: Promise<{ slug: string }> }) {
  const params = await props.params;
  try {
    const data = await anime(params.slug);
    return NextResponse.json({ data }, { status: 200 });
  } catch {
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
