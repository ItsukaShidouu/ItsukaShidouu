import { NextResponse } from "next/server";
import episode from "@/utils/episode";

export const dynamic = "force-dynamic";

export async function GET(_: Request, props: { params: Promise<{ slug: string }> }) {
  const params = await props.params;
  const data = await episode({ episodeSlug: params.slug });
  return NextResponse.json({ data }, { status: 200 });
}
