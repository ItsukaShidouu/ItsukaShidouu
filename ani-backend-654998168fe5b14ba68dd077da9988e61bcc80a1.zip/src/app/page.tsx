// app/page.tsx
import { redirect } from "next/navigation";

export default async function HomePage(): Promise<null> {
  redirect("https://ness.biz.id");
  return null;
}
