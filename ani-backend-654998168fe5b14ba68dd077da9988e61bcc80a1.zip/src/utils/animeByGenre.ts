import axios from "axios";
import { buildOtakudesuUrl } from "@/lib/otakudesu";
import scrapeAnimeByGenre from "@/lib/scrapeAnimeByGenre";

const animeByGenre = async (genre: string, page: number | string = 1) => {
  const response = await axios.get(buildOtakudesuUrl(`/genres/${genre}/page/${page}`));
  const result = scrapeAnimeByGenre(response.data);

  return result;
};

export default animeByGenre;
