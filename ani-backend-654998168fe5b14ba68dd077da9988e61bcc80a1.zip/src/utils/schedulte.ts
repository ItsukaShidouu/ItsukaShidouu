import axios from "axios";
import { buildOtakudesuUrl } from "@/lib/otakudesu";
import scrapSchedule from "@/lib/scrapeSchedule";

const schedule = async () => {
  const response = await axios.get(buildOtakudesuUrl("/jadwal-rilis"));
  const result = scrapSchedule(response.data);

  return result;
};

export default schedule;
