import axios from "axios";
import scrapeSingleAnime from "@/lib/scrapeSingleAnime";
import { buildOtakudesuUrl } from "@/lib/otakudesu";
import type { anime as animeType } from "@/types/types";

const anime = async (slug: string): Promise<animeType | undefined> => {
  const { data } = await axios.get(buildOtakudesuUrl(`/anime/${slug}`));
  const result = scrapeSingleAnime(data);

  return result;
};

export default anime;
