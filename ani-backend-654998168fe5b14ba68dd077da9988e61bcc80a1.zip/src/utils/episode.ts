import axios from "axios";
import scrapeEpisode from "@/lib/scrapeEpisode";
import { buildOtakudesuUrl } from "@/lib/otakudesu";
import { resolveEpisodeMirrors } from "@/lib/resolveEpisodeStreams";
import type { episode_list } from "@/types/types";
import episodes from "./episodes";

const normalizeEpisodeQuery = (value: string) => value.toLowerCase().replace(/[^a-z0-9]+/g, "");

const findEpisodeByQuery = (episodeLists: episode_list[], query: string) => {
  const normalizedQuery = normalizeEpisodeQuery(query);
  const numericQuery = /^\d+$/.test(query) ? parseInt(query, 10) : undefined;

  return episodeLists.find((item) => {
    if (numericQuery !== undefined && item.episode_number === numericQuery) {
      return true;
    }

    const slug = item.slug ? normalizeEpisodeQuery(item.slug) : "";
    const episodeTitle = item.episode ? normalizeEpisodeQuery(item.episode) : "";

    return slug === normalizedQuery
      || episodeTitle === normalizedQuery
      || slug.includes(normalizedQuery)
      || episodeTitle.includes(normalizedQuery);
  });
};

const episode = async ({
  episodeSlug,
  animeSlug,
  episodeNumber,
  episodeQuery,
}: {
  episodeSlug?: string | undefined;
  animeSlug?: string | undefined;
  episodeNumber?: number | undefined;
  episodeQuery?: string | undefined;
}) => {
  let slug = "";

  if (episodeSlug) slug = episodeSlug;
  if (animeSlug && (episodeNumber !== undefined || episodeQuery)) {
    const episodeLists = await episodes(animeSlug);
    if (!episodeLists) return undefined;

    const matchedEpisode = episodeNumber !== undefined
      ? episodeLists.find((item) => item.episode_number === episodeNumber)
      : episodeQuery
        ? findEpisodeByQuery(episodeLists, episodeQuery)
        : undefined;

    if (!matchedEpisode?.slug) {
      return undefined;
    }

    slug = matchedEpisode.slug;
  }

  const { data } = await axios.get(buildOtakudesuUrl(`/episode/${slug}`));
  const result = scrapeEpisode(data);
  if (!result) return undefined;

  const mirrors = await resolveEpisodeMirrors(result.mirrors);

  return {
    ...result,
    mirrors,
  };
};

export default episode;
