import axios from "axios";
import { buildOtakudesuUrl } from "@/lib/otakudesu";
import scrapeAnimeEpisodes from "@/lib/scrapeAnimeEpisodes";
import type { episode_list } from "@/types/types";

const episodes = async (slug: string): Promise<episode_list[] | undefined> => {
  const { data } = await axios.get(buildOtakudesuUrl(`/anime/${slug}`));
  const result = scrapeAnimeEpisodes(data);

  return result;
};

export default episodes;
