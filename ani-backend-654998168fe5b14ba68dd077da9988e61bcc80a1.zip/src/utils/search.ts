import axios from "axios";
import { buildOtakudesuUrl } from "@/lib/otakudesu";
import scrapeSearchResult from "@/lib/scrapeSearchResult";
import { searchResultAnime } from "@/types/types";

const search = async (keyword: string): Promise<searchResultAnime[]> => {
  const response = await axios.get(buildOtakudesuUrl(`/?s=${keyword}&post_type=anime`));
  const html = response.data;
  const searchResult = scrapeSearchResult(html);
  return searchResult;
};

export default search;
