import axios from "axios";
import getBatch from "@/lib/getBatch";
import { buildOtakudesuUrl } from "@/lib/otakudesu";
import scrapeBatch from "@/lib/scrapeBatch";

const batch = async ({
  batchSlug,
  animeSlug,
}: {
  batchSlug?: string;
  animeSlug?: string;
}) => {
  let batch: string | undefined = batchSlug;

  if (animeSlug) {
    const response = await axios.get(buildOtakudesuUrl(`/anime/${animeSlug}`));
    const batchData = getBatch(response.data);
    batch = batchData?.slug;
  }

  const response = await axios.get(buildOtakudesuUrl(`/batch/${batch}`));
  const result = scrapeBatch(response.data);

  return result;
};

export default batch;
