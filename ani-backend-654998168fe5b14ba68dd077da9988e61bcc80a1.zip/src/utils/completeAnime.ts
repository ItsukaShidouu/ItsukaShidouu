import axios from "axios";
import { load } from "cheerio";
import { buildOtakudesuUrl } from "@/lib/otakudesu";
import pagination from "@/lib/pagination";
import scrapeCompleteAnime from "@/lib/scrapeCompleteAnime";

const completeAnime = async (page: number | string = 1) => {
  const { data } = await axios.get(buildOtakudesuUrl(`/complete-anime/page/${page}`));
  const $ = load(data);
  const completeAnimeEls = $(".venutama .rseries .rapi .venz ul li").toString();
  const completeAnimeData = scrapeCompleteAnime(completeAnimeEls);
  const paginationData = pagination($(".pagination").toString());

  return {
    paginationData,
    completeAnimeData,
  };
};

export default completeAnime;
