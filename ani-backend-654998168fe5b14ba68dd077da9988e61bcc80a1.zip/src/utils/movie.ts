import axios from "axios";
import { load } from "cheerio";
import { buildOtakudesuUrl, extractSlugFromUrl } from "@/lib/otakudesu";

type DownloadLinkGroup = {
  quality: string;
  links: { name: string; url: string }[];
};

const movie = async (slug: string): Promise<any> => {
  const { data } = await axios.get(buildOtakudesuUrl(`/episode/${slug}`));
  const primaryPage = load(data);

  const checkUrl = primaryPage(".episodelist ul li span a").attr("href");
  const fixedUrl = extractSlugFromUrl(checkUrl, "episode");

  const fallbackPage = fixedUrl
    ? load((await axios.get(buildOtakudesuUrl(`/episode/${fixedUrl}`))).data)
    : null;

  const page = primaryPage(".yondarkness-title").length > 0 || primaryPage(".yondarkness-item").length > 0
    ? primaryPage
    : fallbackPage ?? primaryPage;
  const title = primaryPage(".posttl").html() ?? fallbackPage?.(".posttl").html();
  const iframeSrc = primaryPage("iframe").attr("src") ?? fallbackPage?.("iframe").attr("src");
  const downloadLinks: DownloadLinkGroup[] = [];

  page(".yondarkness-title").each((_, element) => {
    const quality = page(element).text().trim();
    const links: { name: string; url: string }[] = [];
    page(element)
      .next(".yondarkness-item")
      .find("a")
      .each((__, el) => {
        const name = page(el).text().trim();
        const url = page(el).attr("href") ?? "";
        links.push({ name, url });
      });
    downloadLinks.push({ quality, links });
  });

  if (downloadLinks.length === 0) {
    page(".yondarkness-item").each((_, element) => {
      const quality = page(element).find("a").text().trim();
      const links: { name: string; url: string }[] = [];
      page(element)
        .find("a")
        .each((__, el) => {
          const name = page(el).text().trim();
          const url = page(el).attr("href") ?? "";
          links.push({ name, url });
        });
      downloadLinks.push({ quality, links });
    });
  }

  return { title, iframeSrc, downloadLinks };
};

export default movie;
