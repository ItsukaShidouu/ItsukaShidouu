import axios from "axios";
import "dotenv/config";
import { buildOtakudesuUrl } from "@/lib/otakudesu";
import scrapeGenreLists from "../lib/scrapeGenreLists";
import type { genre as genreType } from "../types/types";

const genreLists = async (): Promise<genreType[]> => {
  const response = await axios.get(buildOtakudesuUrl("/genre-list"));
  const result = scrapeGenreLists(response.data);

  return result;
};

export default genreLists;
