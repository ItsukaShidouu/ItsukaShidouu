# Otakudesu API Scraper

This is a simple API scraper for Otakudesu website.

<strong>PS: This project is for educational purposes only. Use it at your own risk.</strong>

## Star History

[![Star History Chart](https://api.star-history.com/svg?repos=rizkyhaksono/otakudesu-be&type=Date)](https://star-history.com/#rizkyhaksono/otakudesu-be&Date)

## Installation

Copy `.env.example` to `.env` and set `BASEURL` to the Otakudesu website.

```bash
npm install
```

## Running

```bash
npm run start
```

## API List

Base URL lokal saat development biasanya:

```text
http://localhost:3000
```

Daftar endpoint:

- `GET /api`
- `GET /api/home`
- `GET /api/ongoing-anime`
- `GET /api/ongoing-anime/:id`
- `GET /api/complete-anime`
- `GET /api/complete-anime/:page`
- `GET /api/schedule`
- `GET /api/search`
- `GET /api/search/:keyword`
- `GET /api/anime`
- `GET /api/anime/:slug`
- `GET /api/anime/:slug/episodes`
- `GET /api/anime/:slug/episodes/:episode`
- `GET /api/episode`
- `GET /api/episode/:slug`
- `GET /api/batch`
- `GET /api/batch/:slug`
- `GET /api/genre`
- `GET /api/genre/:slug?page=:page`

## Contoh Output API

### 1) GET `/api`

```json
[
  {
    "message": "Otakudesu unofficial API, made by yusupkakuu with 🤍",
    "GitHub": "https://github.com/neofetchnpc",
    "Support": "https://saweria.co/YUSUP909"
  }
]
```

### 2) GET `/api/home`

```json
{
  "data": {
    "ongoing_anime": [
      {
        "title": "One Piece",
        "slug": "one-piece",
        "poster": "https://...jpg",
        "current_episode": "Episode 1090",
        "release_day": "Minggu",
        "newest_release_date": "23 Februari 2026",
        "otakudesu_url": "https://otakudesu.xxx/anime/one-piece/"
      }
    ],
    "complete_anime": [
      {
        "title": "Bocchi the Rock!",
        "slug": "bocchi-the-rock",
        "poster": "https://...jpg",
        "episode_count": "12",
        "rating": "8.6",
        "last_release_date": "25 Desember 2022",
        "otakudesu_url": "https://otakudesu.xxx/anime/bocchi-the-rock/"
      }
    ]
  }
}
```

### 3) GET `/api/ongoing-anime` atau `/api/ongoing-anime/:id`

```json
{
  "data": {
    "paginationData": {
      "current_page": 1,
      "last_visible_page": 5,
      "has_next_page": true,
      "next_page": 2,
      "has_previous_page": false,
      "previous_page": null
    },
    "ongoingAnimeData": [
      {
        "title": "One Piece",
        "slug": "one-piece",
        "poster": "https://...jpg",
        "current_episode": "Episode 1090",
        "release_day": "Minggu",
        "newest_release_date": "23 Februari 2026",
        "otakudesu_url": "https://otakudesu.xxx/anime/one-piece/"
      }
    ]
  }
}
```

### 4) GET `/api/complete-anime` (tanpa page)

```json
{
  "data": "You have to add [:page]"
}
```

### 5) GET `/api/complete-anime/:page`

```json
{
  "data": {
    "paginationData": {
      "current_page": 1,
      "last_visible_page": 12,
      "has_next_page": true,
      "next_page": 2,
      "has_previous_page": false,
      "previous_page": null
    },
    "completeAnimeData": [
      {
        "title": "Bocchi the Rock!",
        "slug": "bocchi-the-rock",
        "poster": "https://...jpg",
        "episode_count": "12",
        "rating": "8.6",
        "last_release_date": "25 Desember 2022",
        "otakudesu_url": "https://otakudesu.xxx/anime/bocchi-the-rock/"
      }
    ]
  }
}
```

### 6) GET `/api/schedule`

```json
{
  "data": [
    {
      "day": "Senin",
      "anime_list": [
        {
          "anime_name": "One Piece",
          "url": "https://otakudesu.natee.my.id/anime/one-piece",
          "slug": "one-piece"
        }
      ]
    }
  ]
}
```

### 7) GET `/api/search` (tanpa keyword)

```json
{
  "data": "You need to put [:keyword]"
}
```

### 8) GET `/api/search/:keyword`

```json
{
  "data": [
    {
      "title": "One Piece",
      "slug": "one-piece",
      "poster": "https://...jpg",
      "status": "Ongoing",
      "rating": "8.9",
      "genres": [
        {
          "name": "Action",
          "slug": "action",
          "otakudesu_url": "https://otakudesu.xxx/genres/action/"
        }
      ],
      "url": "https://otakudesu.xxx/anime/one-piece/"
    }
  ]
}
```

### 9) GET `/api/anime` (tanpa slug)

```json
{
  "data": "You need to add [:slug]"
}
```

### 10) GET `/api/anime/:slug`

```json
{
  "data": {
    "title": "One Piece",
    "slug": "one-piece",
    "japanese_title": "ワンピース",
    "poster": "https://...jpg",
    "rating": "8.9",
    "produser": "Toei Animation",
    "type": "TV",
    "status": "Ongoing",
    "episode_count": "?",
    "duration": "24 min",
    "release_date": "1999",
    "studio": "Toei Animation",
    "genres": [
      {
        "name": "Action",
        "slug": "action",
        "otakudesu_url": "https://otakudesu.xxx/genres/action/"
      }
    ],
    "synopsis": "...",
    "batch": {
      "slug": "one-piece-batch",
      "otakudesu_url": "https://otakudesu.xxx/batch/one-piece-batch/",
      "uploaded_at": "..."
    },
    "episode_lists": [
      {
        "episode": "One Piece Episode 1",
        "episode_number": 1,
        "slug": "one-piece-episode-1-sub-indo",
        "otakudesu_url": "https://otakudesu.xxx/episode/one-piece-episode-1-sub-indo/"
      }
    ],
    "recommendations": [
      {
        "title": "Naruto",
        "slug": "naruto",
        "poster": "https://...jpg",
        "otakudesu_url": "https://otakudesu.xxx/anime/naruto/"
      }
    ]
  }
}
```

### 11) GET `/api/anime/:slug/episodes`

```json
{
  "data": {
    "title": "One Piece Episode 1090 Subtitle Indonesia",
    "iframeSrc": "https://...",
    "downloadLinks": [
      {
        "quality": "360p",
        "links": [
          {
            "name": "Google Drive",
            "url": "https://..."
          }
        ]
      }
    ]
  }
}
```

### 12) GET `/api/anime/:slug/episodes/:episode`

```json
{
  "data": {
    "episode": "One Piece Episode 1090 Subtitle Indonesia",
    "anime": {
      "slug": "one-piece",
      "otakudesu_url": "https://otakudesu.xxx/anime/one-piece/"
    },
    "has_next_episode": true,
    "next_episode": {
      "slug": "one-piece-episode-1091-sub-indo",
      "otakudesu_url": "https://otakudesu.xxx/episode/one-piece-episode-1091-sub-indo/"
    },
    "has_previous_episode": true,
    "previous_episode": {
      "slug": "one-piece-episode-1089-sub-indo",
      "otakudesu_url": "https://otakudesu.xxx/episode/one-piece-episode-1089-sub-indo/"
    },
    "stream_url": "https://...",
    "download_urls": {
      "mp4": [
        {
          "resolution": "360p",
          "urls": [
            {
              "provider": "Zippyshare",
              "url": "https://..."
            }
          ]
        }
      ],
      "mkv": [
        {
          "resolution": "720p",
          "urls": [
            {
              "provider": "Google Drive",
              "url": "https://..."
            }
          ]
        }
      ]
    }
  }
}
```

### 13) GET `/api/episode` (tanpa slug)

```json
{
  "data": "You need to put [:slug]"
}
```

### 14) GET `/api/episode/:slug`

```json
{
  "data": {
    "episode": "One Piece Episode 1090 Subtitle Indonesia",
    "anime": {
      "slug": "one-piece",
      "otakudesu_url": "https://otakudesu.xxx/anime/one-piece/"
    },
    "has_next_episode": true,
    "next_episode": {
      "slug": "one-piece-episode-1091-sub-indo",
      "otakudesu_url": "https://otakudesu.xxx/episode/one-piece-episode-1091-sub-indo/"
    },
    "has_previous_episode": true,
    "previous_episode": {
      "slug": "one-piece-episode-1089-sub-indo",
      "otakudesu_url": "https://otakudesu.xxx/episode/one-piece-episode-1089-sub-indo/"
    },
    "stream_url": "https://...",
    "download_urls": {
      "mp4": [
        {
          "resolution": "360p",
          "urls": [
            {
              "provider": "Zippyshare",
              "url": "https://..."
            }
          ]
        }
      ],
      "mkv": [
        {
          "resolution": "720p",
          "urls": [
            {
              "provider": "Google Drive",
              "url": "https://..."
            }
          ]
        }
      ]
    }
  }
}
```

### 15) GET `/api/batch` (tanpa slug)

```json
{
  "data": "You need to add [:slug]"
}
```

### 16) GET `/api/batch/:slug`

```json
{
  "data": {
    "batch": "One Piece Batch Subtitle Indonesia",
    "download_urls": [
      {
        "resolution": "360p",
        "file_size": "1.2 GB",
        "urls": [
          {
            "provider": "Google Drive",
            "url": "https://..."
          }
        ]
      }
    ]
  }
}
```

### 17) GET `/api/genre`

```json
{
  "data": [
    {
      "name": "Action",
      "slug": "action",
      "otakudesu_url": "https://otakudesu.xxx/genres/action/"
    }
  ]
}
```

### 18) GET `/api/genre/:slug?page=1`

```json
{
  "data": {
    "anime": [
      {
        "title": "One Piece",
        "slug": "one-piece",
        "poster": "https://...jpg",
        "rating": "8.9",
        "episode_count": "1090",
        "season": "Fall 1999",
        "studio": "Toei Animation",
        "genres": [
          {
            "name": "Action",
            "slug": "action",
            "otakudesu_url": "https://otakudesu.xxx/genres/action/"
          }
        ],
        "synopsis": "...",
        "otakudesu_url": "https://otakudesu.xxx/anime/one-piece/"
      }
    ],
    "pagination": {
      "current_page": 1,
      "last_visible_page": 20,
      "has_next_page": true,
      "next_page": 2,
      "has_previous_page": false,
      "previous_page": null
    }
  }
}
```

## License

[MIT License](./LICENSE)

## Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.
